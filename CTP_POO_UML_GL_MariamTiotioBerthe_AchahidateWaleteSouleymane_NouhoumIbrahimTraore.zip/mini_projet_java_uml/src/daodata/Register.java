package daodata;

public class Register {
	private String id;
	private String nom;
	private String prenom;
	private String nu; 
	private String mp;
	private String email;
	private String niv;
	private String tel;
	/**
	 * @param nom
	 * @param prenom
	 * @param nu
	 * @param mp
	 * @param email
	 * @param niv
	 * @param tel
	 */
	public Register(String nom,String prenom, String nu, String mp, String email, String niv, String tel) {
		super();
		this.nom = nom;
		this.prenom=prenom;
		this.nu = nu;
		this.mp = mp;
		this.email = email;
		this.niv = niv;
		this.tel = tel;
	}
	
	
	
	/**
	 * @param nu
	 * @param mp
	 */
	public Register(String email, String mp) {
		super();
		this.email = email;
		this.mp = mp;
	}


	

	/**
	 * @param nom
	 * @param prenom
	 * @param mp
	 * @param email
	 */
	public Register(String nom, String prenom,  String email,String mp) {
		super();
		this.nom = nom;
		this.prenom = prenom;
		this.email = email;
		this.mp = mp;
	}


	

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}



	public Register(String email2) {
		this.email=email2;
	}



	/**
	 * @return the nom
	 */
	public String getNom() {
		return nom;
	}
	/**
	 * @param np the nom to set
	 */
	public void setNp(String np) {
		this.nom = np;
	}
	
	
	
	/**
	 * @return the prenom
	 */
	public String getPrenom() {
		return prenom;
	}



	/**
	 * @param prenom the prenom to set
	 */
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}



	/**
	 * @return the nu
	 */
	public String getNu() {
		return nu;
	}
	/**
	 * @param nu the nu to set
	 */
	public void setNu(String nu) {
		this.nu = nu;
	}
	/**
	 * @return the mp
	 */
	public String getMp() {
		return mp;
	}
	/**
	 * @param mp the mp to set
	 */
	public void setMp(String mp) {
		this.mp = mp;
	}
	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}
	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	/**
	 * @return the niv
	 */
	public String getNiv() {
		return niv;
	}
	/**
	 * @param niv the niv to set
	 */
	public void setNiv(String niv) {
		this.niv = niv;
	}
	/**
	 * @return the tel
	 */
	public String getTel() {
		return tel;
	}
	/**
	 * @param tel the tel to set
	 */
	public void setTel(String tel) {
		this.tel = tel;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Register [np=" + nom + ", nu=" + nu + ", mp=" + mp + ", email=" + email + ", niv=" + niv + ", tel=" + tel
				+ "]";
	}
	
	
	
	
	
 }
