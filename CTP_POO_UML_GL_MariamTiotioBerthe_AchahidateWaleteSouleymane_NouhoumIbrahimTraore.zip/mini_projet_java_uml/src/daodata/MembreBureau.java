/**
 * 
 */
package daodata;

/**
 * @author Mariam Tiotio Berthe
 *
 */
/**
 * @author Mariam Tiotio Berthe
 *
 */
public class MembreBureau {
	
	/**
	 * 
	 */
	private int id;
	private String nom;
	private String prenom; 
	private String nu;
	private String pwd;
	private String email;
	private String niv;
	private String tel;
	private String fonction;
	/**
	 * @param nom
	 * @param prenom
	 * @param email
	 * @param fonction
	 */
	public MembreBureau (String nom, String prenom, String email, String fonction) {
		super();
		this.nom = nom;
		this.prenom = prenom;
		this.email = email;
		this.fonction = fonction;
	}
	
	
	
	/**
	 * @param id
	 * @param fonction
	 */
	public MembreBureau( String fonction,int id) {
		super();
		this.fonction = fonction;
		this.id = id;
	}
	
	



	/**
	 * @param id
	 */
	public MembreBureau(int id) {
		super();
		this.id = id;
	}



	public MembreBureau(String email2, String mp) {
		this.email=email2;
		this.pwd=mp;
	}



	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}



	/**
	 * @return the nom
	 */
	public String getNom() {
		return nom;
	}
	/**
	 * @return the prenom
	 */
	public String getPrenom() {
		return prenom;
	}
	/**
	 * @return the nu
	 */
	public String getNu() {
		return nu;
	}
	/**
	 * @return the pwd
	 */
	public String getPwd() {
		return pwd;
	}
	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}
	/**
	 * @return the niv
	 */
	public String getNiv() {
		return niv;
	}
	/**
	 * @return the tel
	 */
	public String getTel() {
		return tel;
	}
	/**
	 * @return the fonction
	 */
	public String getFonction() {
		return fonction;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Bureau [nom=" + nom + ", prenom=" + prenom + ", nu=" + nu + ", pwd=" + pwd + ", email=" + email
				+ ", niv=" + niv + ", tel=" + tel + ", fonction=" + fonction + ", getNom()=" + getNom()
				+ ", getPrenom()=" + getPrenom() + ", getNu()=" + getNu() + ", getPwd()=" + getPwd() + ", getEmail()="
				+ getEmail() + ", getNiv()=" + getNiv() + ", getTel()=" + getTel() + ", getFonction()=" + getFonction()
				+ "]";
	}
	
	
	
	
	
	

}
