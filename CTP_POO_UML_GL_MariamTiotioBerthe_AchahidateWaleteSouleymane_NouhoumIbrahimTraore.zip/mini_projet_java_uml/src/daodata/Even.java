package daodata;

public class Even {
	private String intl;
	private String cnt;
	private String dt;
	private String hre;
	/**
	 * @param intl
	 * @param cnt
	 * @param dt
	 * @param hre
	 */
	public Even(String intl, String cnt, String dt, String hre) {
		super();
		this.intl = intl;
		this.cnt = cnt;
		this.dt = dt;
		this.hre = hre;
	}
	public Even(String intitul�) {
		this.intl= intitul�;
		// TODO Auto-generated constructor stub
	}
	/**
	 * @return the intl
	 */
	public String getIntl() {
		return intl;
	}
	/**
	 * @return the cnt
	 */
	public String getCnt() {
		return cnt;
	}
	/**
	 * @return the dt
	 */
	public String getDt() {
		return dt;
	}
	/**
	 * @return the hre
	 */
	public String getHre() {
		return hre;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Even [intl=" + intl + ", cnt=" + cnt + ", dt=" + dt + ", hre=" + hre + "]";
	}
	
	

}
