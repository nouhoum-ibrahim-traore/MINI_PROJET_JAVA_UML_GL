package daodata;

public class NewPassword {
	private String email;
	private String pwd;
	/**
	 * @param pwd
	 * @param email
	 */
	public NewPassword( String email,String pwd) {
		super();
		this.email = email;
		this.pwd = pwd;
		
	}
	/**
	 * @return the pwd
	 */
	public String getPwd() {
		return pwd;
	}
	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "NewPassword [pwd=" + pwd + ", email=" + email + "]";
	}
	
	
}
