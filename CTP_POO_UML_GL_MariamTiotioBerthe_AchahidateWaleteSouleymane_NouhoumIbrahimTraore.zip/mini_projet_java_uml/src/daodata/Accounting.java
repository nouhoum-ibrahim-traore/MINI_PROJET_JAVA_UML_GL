package daodata;

public class Accounting {
	private int id;
	private String nu;
	private String email;
	private String tel;
	private String montant;
	/**
	 * @param nu
	 * @param email
	 * @param tel
	 * @param montant
	 */
	public Accounting(String nu, String email, String tel,String montant) {
		super();
		this.nu = nu;
		this.email = email;
		this.tel = tel;
		this.montant=montant;
	}
	
	
	
	/**
	 * @param id
	 * @param montant
	 */
	public Accounting(String montant, int id) {
		super();
		this.montant = montant;
		this.id = id;
	}
	
	



	/**
	 * @param id
	 */
	public Accounting(int id) {
		super();
		this.id = id;
	}



	public Accounting(String email2) {
		this.email=email2;
	}



	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}



	/**
	 * @return the nu
	 */
	public String getNu() {
		return nu;
	}
	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}
	/**
	 * @return the tel
	 */
	public String getTel() {
		return tel;
	}
	
	
	/**
	 * @return the montant
	 */
	public String getMontant() {
		return montant;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Accounting [nu=" + nu + ", email=" + email + ", tel=" + tel + "]";
	}

	
	

}
