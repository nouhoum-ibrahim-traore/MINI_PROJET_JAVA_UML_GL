package mini_pojet_gi_java;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JTable;
import javax.swing.JButton;

import java.awt.Color;
import java.awt.Font;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;

import connectionDAO.AddInDB;
import connectionDAO.Connect;
import connectionDAO.UpdateInDB;
import daodata.Even;
import net.proteanit.sql.DbUtils;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

/**
 *@author Mariam Tiotio Berthe
 * @author Nouhoum Ibrahim Traore
 * @author Achahidat Wallet Souleymane
 * 
 * Class qui herite de jframe et qui implemente les interfaces pour l'ajout,
 * l'affichage la modification et la suppressiont dans la base de donn�e
 *Elle permettra la gestion des �v�nement
 */
public class IntBureauChargeEvent extends JFrame implements AddInDB, UpdateInDB {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField jtextField_intitul�;
	private JTable table;
	JTextArea jtextArea;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					IntBureauChargeEvent frame = new IntBureauChargeEvent();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public IntBureauChargeEvent() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 743, 400);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(250, 250, 210));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		this.setLocationRelativeTo(null);
		
		JLabel lblIntitul = new JLabel("Intitul\u00E9");
		lblIntitul.setForeground(Color.ORANGE);
		lblIntitul.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		
		jtextField_intitul� = new JTextField();
		jtextField_intitul�.setColumns(10);
		
		JLabel lblDescription = new JLabel("Description");
		lblDescription.setForeground(Color.ORANGE);
		lblDescription.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		
		jtextArea = new JTextArea();
		
		JButton btnAjouter = new JButton("Ajouter");
		btnAjouter.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnAjouter.setBackground(Color.WHITE);
		btnAjouter.setForeground(Color.ORANGE);
		
		JButton btnSuppriler = new JButton("Supprimer");
		btnSuppriler.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				supprimer();
			}
		});
		btnSuppriler.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnSuppriler.setBackground(Color.WHITE);
		btnSuppriler.setForeground(Color.ORANGE);
		
		JButton btnAfficherListeEvenement = new JButton("Afficher liste evenement");
		btnAfficherListeEvenement.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				afficher();
			}
		});
		btnAfficherListeEvenement.setForeground(Color.ORANGE);
		btnAfficherListeEvenement.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnAfficherListeEvenement.setBackground(Color.WHITE);
		
		JButton btnRetour = new JButton("Retour");
		btnRetour.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				IntBureauChargInfo log = new IntBureauChargInfo();
				log.setVisible(true);
				log.setLocationRelativeTo(null);
				log.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				IntBureauChargeEvent.this.dispose();
			}
		});
		btnRetour.setForeground(Color.ORANGE);
		btnRetour.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnRetour.setBackground(Color.WHITE);
		
		JScrollPane scrollPane = new JScrollPane();
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap(16, Short.MAX_VALUE)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(lblDescription, GroupLayout.PREFERRED_SIZE, 94, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(jtextArea, GroupLayout.PREFERRED_SIZE, 161, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(lblIntitul, GroupLayout.PREFERRED_SIZE, 62, GroupLayout.PREFERRED_SIZE)
							.addGap(34)
							.addComponent(jtextField_intitul�, GroupLayout.PREFERRED_SIZE, 140, GroupLayout.PREFERRED_SIZE)))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 415, GroupLayout.PREFERRED_SIZE)
					.addContainerGap())
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(84)
					.addComponent(btnAjouter)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addPreferredGap(ComponentPlacement.RELATED, 322, Short.MAX_VALUE)
							.addComponent(btnAfficherListeEvenement, GroupLayout.PREFERRED_SIZE, 198, GroupLayout.PREFERRED_SIZE)
							.addGap(36))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(48)
							.addComponent(btnSuppriler)
							.addContainerGap())))
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(83)
					.addComponent(btnRetour, GroupLayout.PREFERRED_SIZE, 75, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(557, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(22)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
								.addComponent(lblIntitul)
								.addComponent(jtextField_intitul�, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addGap(76)
									.addComponent(lblDescription))
								.addGroup(gl_contentPane.createSequentialGroup()
									.addGap(40)
									.addComponent(jtextArea, GroupLayout.PREFERRED_SIZE, 98, GroupLayout.PREFERRED_SIZE))))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addContainerGap()
							.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 252, GroupLayout.PREFERRED_SIZE)))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
							.addComponent(btnAjouter)
							.addGap(20)
							.addComponent(btnRetour)
							.addGap(6))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(btnSuppriler)
							.addPreferredGap(ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
							.addComponent(btnAfficherListeEvenement)
							.addContainerGap())))
		);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null},
			},
			new String[] {
				"ID", "Intitul\u00E9", "Contenu", "Date", "Heure"
			}
		));
		table.getColumnModel().getColumn(2).setPreferredWidth(158);
		scrollPane.setViewportView(table);
		contentPane.setLayout(gl_contentPane);
	}

	@Override
	public void modifier() {
		// TODO Auto-generated method stub
		
	}
	/**r�definition de la methode supprimer   
	 */

	@Override
	public void supprimer() {
		String intitul� = jtextField_intitul�.getText();
		Even even = new Even(intitul�);
		Connect c = new Connect();
		Connection con = c.connect();
		PreparedStatement pst = null;

		try {
			
			pst = con.prepareStatement("DELETE FROM `ev�nement` WHERE `ev�nement`.`Intitul�` = ?");
			//set 
			pst.setString(1, even.getIntl());
			//execute
			pst.executeUpdate();
			//close 
			pst.close();
			
		} catch (SQLException e) {e.printStackTrace();} 
				
	}

	/**r�definition de la methode afficher de l'interface UpdateInDB pour l'affichage des donn�es  
	 */
	@Override
	public void afficher() {
		

		Connect c = new Connect();
		Connection con = c.connect();
		PreparedStatement pst = null;
		ResultSet rs = null;
		try {
			pst = con.prepareStatement("SELECT * FROM `ev�nement`");
			rs = pst.executeQuery();
			table.setModel(DbUtils.resultSetToTableModel(rs));
			
			//close
			pst.close();
			rs.close();
		} catch (SQLException e) {e.printStackTrace();}
		
	
		try {
			pst = con.prepareStatement("SELECT Contenu FROM `ev�nement`");
			rs = pst.executeQuery();
			while(rs.next()) {
				String contenu = rs.getString("Contenu");
				jtextArea.setText(contenu);
			}
			
			pst.close();
			rs.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	/**r�d�finition de la m�thode ajouter pour l'ajout de la date l'heure
	 * l'intitul� et le contenue de l'ev�nement dans la base de donn�es*/
	/* (non-Javadoc)
	 * @see DaoFactory.AddInDB#ajouter()
	 */
	@Override
	public void ajouter() {

		String intl= jtextField_intitul�.getText();
		String cnt = jtextArea.getText();
		Date actuelle = new Date();
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		SimpleDateFormat h = new SimpleDateFormat ("hh:mm");
		String dat = dateFormat.format(actuelle);
		String heure = h.format(actuelle);
		Even even = new Even(intl,cnt,dat,heure);

		Connect c = new Connect();
		Connection con = c.connect();
		PreparedStatement pst = null;
		
		
				
		try {
			pst = con.prepareStatement("INSERT INTO ev�nement (Intitul�,Contenu,Date,Heure) VALUES (?,?,?,?)");
			
			// set params
			pst.setString(1, even.getIntl());
			pst.setString(2,even.getCnt());
			pst.setString(3, even.getDt());
			pst.setString(4,even.getHre());
			pst.executeUpdate();
			
			pst.close();
		} catch (SQLException e) {

			e.printStackTrace();
		}
		
		JOptionPane.showMessageDialog(null,"Ajout r�ussi !!!");
	}
}
