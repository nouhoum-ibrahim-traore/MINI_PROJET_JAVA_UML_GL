package mini_pojet_gi_java;


import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import mini_pojet_gi_java.Login;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JLabel;
import java.awt.Color;

import java.awt.Font;

public class IntBureauChargInfo extends JFrame {

	/**
	 *  @author Mariam Tiotio Berthe
 * @author Nouhoum Ibrahim Traore
 * @author Achahidat Wallet Souleymane
 * 
 * classe qui h�rute de jFrame 
 * interface user
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					IntBureauChargInfo frame = new IntBureauChargInfo();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public IntBureauChargInfo() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 640, 365);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(250, 250, 210));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		this.setLocationRelativeTo(null);
		
		JButton btnProfil = new JButton("Profile");
		btnProfil.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Profil1 user = new Profil1();
				user.setVisible(true);
				user.setLocationRelativeTo(null);
				user.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				IntBureauChargInfo.this.dispose();
			}
		});
		btnProfil.setForeground(Color.WHITE);
		btnProfil.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnProfil.setBackground(Color.ORANGE);
		
		JButton btnEvnements = new JButton("Ev\u00E9nements");
		btnEvnements.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				IntBureauChargeEvent even = new IntBureauChargeEvent();
				even.setVisible(true);
				even.setLocationRelativeTo(null);
				even.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				IntBureauChargInfo.this.dispose();
			}
		});
		btnEvnements.setBackground(Color.ORANGE);
		btnEvnements.setForeground(Color.WHITE);
		btnEvnements.setFont(new Font("Tahoma", Font.BOLD, 11));
		
		
		
		JLabel lblNewLabel_1 = new JLabel("");
		Image img = new ImageIcon(this.getClass().getResource("/event1.png")).getImage();
		lblNewLabel_1.setIcon(new ImageIcon(img));
		
		
		JLabel lblBienvenue = new JLabel("Bienvenue!");
		lblBienvenue.setForeground(Color.ORANGE);
		lblBienvenue.setBackground(Color.ORANGE);
		lblBienvenue.setFont(new Font("Script MT Bold", Font.BOLD | Font.ITALIC, 30));
		
		JLabel lblNewLabel = new JLabel("");
		Image img2 = new ImageIcon(this.getClass().getResource("/prof.png")).getImage();
		lblNewLabel.setIcon(new ImageIcon(img2));
		
		JLabel lblNewLabel_2 = new JLabel("");
		Image img3 = new ImageIcon(this.getClass().getResource("/event1.png")).getImage();
		lblNewLabel_2.setIcon(new ImageIcon(img3));
		
		JButton button = new JButton("D\u00E9connexion");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Login log = new Login();
				log.setVisible(true);
				log.setLocationRelativeTo(null);
				log.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				IntBureauChargInfo.this.dispose();
			}
		});
		button.setForeground(Color.WHITE);
		button.setFont(new Font("Tahoma", Font.BOLD, 11));
		button.setBackground(Color.ORANGE);
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(24)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addPreferredGap(ComponentPlacement.RELATED, 164, Short.MAX_VALUE)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(lblNewLabel_1, GroupLayout.PREFERRED_SIZE, 222, GroupLayout.PREFERRED_SIZE)
									.addContainerGap())
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(lblBienvenue, GroupLayout.PREFERRED_SIZE, 339, GroupLayout.PREFERRED_SIZE)
									.addGap(87))))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 124, GroupLayout.PREFERRED_SIZE)
								.addComponent(btnProfil, GroupLayout.PREFERRED_SIZE, 86, GroupLayout.PREFERRED_SIZE))
							.addPreferredGap(ComponentPlacement.RELATED, 313, Short.MAX_VALUE)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
								.addComponent(btnEvnements, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(lblNewLabel_2, GroupLayout.DEFAULT_SIZE, 113, Short.MAX_VALUE)
								.addComponent(button, Alignment.TRAILING, GroupLayout.PREFERRED_SIZE, 111, GroupLayout.PREFERRED_SIZE))
							.addGap(40))))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(79)
							.addComponent(lblBienvenue, GroupLayout.PREFERRED_SIZE, 47, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
							.addComponent(lblNewLabel_1, GroupLayout.PREFERRED_SIZE, 0, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(lblNewLabel_2, GroupLayout.PREFERRED_SIZE, 78, GroupLayout.PREFERRED_SIZE)
							.addGap(18)
							.addComponent(btnEvnements, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
							.addGap(5))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addContainerGap()
							.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 87, GroupLayout.PREFERRED_SIZE)
							.addGap(18)
							.addComponent(btnProfil)
							.addPreferredGap(ComponentPlacement.RELATED)))
					.addGap(11)
					.addComponent(button))
		);
		contentPane.setLayout(gl_contentPane);
	}
}
