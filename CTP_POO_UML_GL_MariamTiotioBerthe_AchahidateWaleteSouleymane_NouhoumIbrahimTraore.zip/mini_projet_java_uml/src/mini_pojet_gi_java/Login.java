package mini_pojet_gi_java;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;

import connectionDAO.Connect;
import connectionDAO.UpdateInDB;
import daodata.MembreBureau;
import daodata.Register;
import java.awt.Color;
import java.awt.Cursor;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Login extends JFrame implements UpdateInDB {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField JTextField_email;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Login() {
		
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 500, 393);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setUndecorated(true);
		this.setLocationRelativeTo(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 500, 62);
		panel.setBackground(new Color(119, 181, 254));
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblLogin = new JLabel("G^-^CLUB");
		lblLogin.setForeground(Color.WHITE);
		lblLogin.setFont(new Font("Tahoma", Font.BOLD, 30));
		lblLogin.setBounds(172, 13, 186, 44);
		panel.add(lblLogin);
		
		JLabel JLabel_close = new JLabel("X");
		JLabel_close.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		JLabel_close.addMouseListener(new MouseAdapter() {
			
			@Override
			public void mouseExited(MouseEvent e) {
				Border label_border = BorderFactory.createMatteBorder(1, 1, 1, 1, Color.black);
				JLabel_close.setBorder(label_border);
				JLabel_close.setForeground(Color.black);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				Border label_border = BorderFactory.createMatteBorder(1, 1, 1, 1, Color.red);
				JLabel_close.setBorder(label_border);
				JLabel_close.setForeground(Color.red);
			}
			
			@Override
			public void mouseClicked(MouseEvent arg0) {
				
				System.exit(0);
			}
		});
		JLabel_close.setForeground(Color.BLACK);
		JLabel_close.setFont(new Font("Tahoma", Font.BOLD, 30));
		JLabel_close.setBounds(458, 13, 28, 44);
		panel.add(JLabel_close);
		
		JLabel jlabel_minimize = new JLabel("-");
		jlabel_minimize.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		jlabel_minimize.addMouseListener(new MouseAdapter() {
			
			@Override
			public void mouseExited(MouseEvent e) {
				Border label_border = BorderFactory.createMatteBorder(1, 1, 1, 1, Color.black);
				jlabel_minimize.setBorder(label_border);
				jlabel_minimize.setForeground(Color.black);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				Border label_border = BorderFactory.createMatteBorder(1, 1, 1, 1, Color.white);
				jlabel_minimize.setBorder(label_border);
				jlabel_minimize.setForeground(Color.white);
			}
			
			@Override
			public void mouseClicked(MouseEvent e) {
				
				Login.this.setState(JFrame.ICONIFIED);
			}

		});
		jlabel_minimize.setForeground(Color.BLACK);
		jlabel_minimize.setFont(new Font("Tahoma", Font.BOLD, 30));
		jlabel_minimize.setBounds(414, 13, 28, 44);
		panel.add(jlabel_minimize);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(44,62,80));
		panel_1.setBounds(0, 61, 500, 332);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel jlabel_login = new JLabel("Email :");
		jlabel_login.setIcon(null);
		jlabel_login.setBounds(12, 62, 159, 36);
		jlabel_login.setForeground(new Color(236,240,241));
		jlabel_login.setFont(new Font("Tahoma", Font.BOLD, 16));
		panel_1.add(jlabel_login);
		
		JLabel lblUspassword = new JLabel("Mot de passe :");
		lblUspassword.setBounds(12, 114, 127, 16);
		lblUspassword.setForeground(new Color(236, 240, 241));
		lblUspassword.setFont(new Font("Tahoma", Font.BOLD, 16));
		panel_1.add(lblUspassword);
		
		JTextField_email = new JTextField();
		JTextField_email.setBounds(183, 67, 208, 26);
		JTextField_email.setForeground(Color.WHITE);
		JTextField_email.setBackground(new Color(108,122,137));
		//TextField_username.setForeground(new Color(108,122,137));
		JTextField_email.setFont(new Font("Tahoma", Font.PLAIN, 16));
		panel_1.add(JTextField_email);
		JTextField_email.setColumns(10);
		
		passwordField = new JPasswordField("");
		passwordField.setBounds(183, 109, 208, 26);
		passwordField.setForeground(Color.WHITE);
		passwordField.setBackground(new Color(108,122,137));
		passwordField.setFont(new Font("Tahoma", Font.PLAIN, 16));
		//passwordField.setForeground(new Color(108,122,137));
		panel_1.add(passwordField);
		
		JButton btnLogin = new JButton("Connecter");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				afficher();
			}
		});
		btnLogin.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnLogin.setBounds(284, 169, 127, 29);
		btnLogin.setForeground(Color.WHITE);
		btnLogin.setBackground(new Color(34,167,240));
		btnLogin.setFont(new Font("Tahoma", Font.BOLD, 16));
		panel_1.add(btnLogin);
		
		JButton jbutton_cancel = new JButton("Ajouter");
		jbutton_cancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				RegisterForm register = new RegisterForm();
				register.setVisible(true);
				register.setLocationRelativeTo(null);
				register.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				Login.this.dispose();
			}
		});
		jbutton_cancel.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		jbutton_cancel.setForeground(Color.white);
		jbutton_cancel.setFont(new Font("Tahoma", Font.BOLD, 16));
		jbutton_cancel.setBackground(Color.LIGHT_GRAY);
		jbutton_cancel.setBounds(150, 170, 105, 28);
		panel_1.add(jbutton_cancel);
		
		JLabel jlabel_nouveau_mp = new JLabel("Nouveau mot de passe");
		jlabel_nouveau_mp.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		jlabel_nouveau_mp.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				ForGotPassword f = new ForGotPassword();
				f.setVisible(true);
				f.setLocationRelativeTo(null);
				f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				Login.this.dispose();
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				Border label_border = BorderFactory.createMatteBorder(1, 1, 1, 1, Color.black);
				jlabel_nouveau_mp.setBorder(label_border);
				jlabel_nouveau_mp.setForeground(Color.blue);
			}
			@Override
			public void mouseExited(MouseEvent arg0) {
				jlabel_nouveau_mp.setForeground(Color.WHITE);
				Border label_border = BorderFactory.createMatteBorder(0, 0, 0, 0, Color.black);
				jlabel_nouveau_mp.setBorder(label_border);
			}
		});
		jlabel_nouveau_mp.setForeground(Color.WHITE);
		jlabel_nouveau_mp.setFont(new Font("Tahoma", Font.BOLD, 15));
		jlabel_nouveau_mp.setBounds(183, 238, 176, 26);
		panel_1.add(jlabel_nouveau_mp);
		
	}
	
	@Override
	public void modifier() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void supprimer() {
		// TODO Auto-generated method stub
		
	}

	/**r�definition dela m�thode afficher pour charger les interface graphiques correspondante pour la connexion */
	/* (non-Javadoc)
	 * @see DaoFactory.UpdateInDB#afficher()
	 */
	@Override
	public void afficher() {
		String email = JTextField_email.getText(); 
		String mp =String.valueOf(passwordField.getPassword());
		Register register = new Register (email,mp);
		MembreBureau bureau= new MembreBureau(email,mp); 
		
		Connect c = new Connect();
		Connection con = c.connect();
		PreparedStatement pst = null;
		ResultSet rs = null;
		if(email.equals("admin") && mp.equals("admin")){
			Admin t= new Admin();
			t.setVisible(true);
			t.setLocationRelativeTo(null);
			t.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		}
		else {
			try {
				pst = con.prepareStatement("SELECT * FROM `account` WHERE  Email= ? AND Mot_de_Passe= ?");
				pst.setString(1, register.getEmail());
				pst.setString(2, register.getMp());
				
				rs = pst.executeQuery();
				
				
				if(rs.next()) {
					if (rs.getString("Email").equals(email) && rs.getString("Mot_de_Passe").equals(mp)) {
						rs.close();/**pour la fermeture de differents reulset et preparedStatment*/
						rs.close();
						setVisible(false);
						IntUser t= new IntUser();
						t.setVisible(true);
						t.setLocationRelativeTo(null);
						t.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
						}
					
					}
				else {
					try {
						pst = con.prepareStatement("SELECT * FROM `Membre_Bureau` WHERE  Email= ? AND Mot_de_Passe= ?");
						pst.setString(1, bureau.getEmail());
						pst.setString(2, bureau.getPwd());
						
						rs = pst.executeQuery();
						
						
						if(rs.next()) {
							if (rs.getString("Email").equals(email) && rs.getString("Mot_de_Passe").equals(mp)) {
								if (rs.getString("Fonction").equals("Tr�sorier")){
									rs.close();/**pour la fermeture de differents reulset et preparedStatment*/
									rs.close();
									setVisible(false);
									IntBureauTresorier t= new IntBureauTresorier();
									t.setVisible(true);
									t.setLocationRelativeTo(null);
									t.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
								}
								else if (rs.getString("Fonction").equals("Secretaire")) {
									IntBureauChargInfo t= new IntBureauChargInfo();
									t.setVisible(true);
									t.setLocationRelativeTo(null);
									t.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
									}
								}
							}
						else {
							JOptionPane.showMessageDialog(null,"nom d'utilisateur incorect ou mot de passe incorect");
						}
						} catch (SQLException e) {e.printStackTrace();}
				}
//				else {
//						JOptionPane.showMessageDialog(null,"nom d'utilisateur incorect ou mot de passe incorect");
//					}
				
				
				
				} catch (SQLException e) {e.printStackTrace();}
					
						
						
					}
	}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

