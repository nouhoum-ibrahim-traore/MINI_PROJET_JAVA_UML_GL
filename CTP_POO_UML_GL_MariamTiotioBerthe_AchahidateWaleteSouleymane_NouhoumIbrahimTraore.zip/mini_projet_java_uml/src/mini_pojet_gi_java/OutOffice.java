package mini_pojet_gi_java;


import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import daodata.Accounting;
import daodata.Register;
import net.proteanit.sql.DbUtils;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JTable;
import javax.swing.JButton;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;

import connectionDAO.AddInDB;
import connectionDAO.Connect;
import connectionDAO.UpdateInDB;

import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.ImageIcon;
import java.awt.Font;

/**
 * @author Mariam Tiotio Berthe
 * @author Nouhoum Ibrahim Traore
 * @author Achahidat Wallet Souleymane
 * 
 * Class qui herite de jframe et qui implemente les interfaces pour l'ajout,
 * l'affichage la modification et la suppressiont dans la base de donn�e
 *Elle permettra � l'admin de modifier,supprimer, ajouter et afficher la liste 
 *d'un adherent qui n'est pas membre du bureau 
 */
public class OutOffice extends JFrame implements AddInDB,UpdateInDB {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField jtextfile_nom;
	private JTextField jtextfile_Prenom;
	private JTextField jtextfile_email;
	private JPasswordField passwordField;
	private JTable table;
	private JTextField jtextField_id;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					OutOffice frame = new OutOffice();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public OutOffice() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 678, 480);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(250, 250, 210));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		this.setLocationRelativeTo(null);
		
		JLabel lblNom = new JLabel("Nom");
		lblNom.setBounds(17, 117, 44, 16);
		lblNom.setFont(new Font("Tahoma", Font.BOLD, 15));
		
		JLabel lblPrnom = new JLabel("Pr\u00E9nom");
		lblPrnom.setBounds(17, 150, 76, 16);
		lblPrnom.setFont(new Font("Tahoma", Font.BOLD, 15));
		
		JLabel lblEmail = new JLabel("Email");
		lblEmail.setBounds(17, 186, 55, 16);
		lblEmail.setFont(new Font("Tahoma", Font.BOLD, 15));
		
		JLabel lblMotDePasse = new JLabel("Mot de passe");
		lblMotDePasse.setBounds(0, 221, 123, 16);
		lblMotDePasse.setFont(new Font("Tahoma", Font.BOLD, 15));
		
		jtextfile_nom = new JTextField();
		jtextfile_nom.setBounds(123, 114, 121, 22);
		jtextfile_nom.setColumns(10);
		
		jtextfile_Prenom = new JTextField();
		jtextfile_Prenom.setBounds(123, 147, 121, 22);
		jtextfile_Prenom.setColumns(10);
		
		jtextfile_email = new JTextField();
		jtextfile_email.setBounds(123, 183, 121, 22);
		jtextfile_email.setColumns(10);
		
		JButton btnAjouter = new JButton("Ajouter");
		btnAjouter.setBounds(17, 308, 75, 25);
		btnAjouter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ajouter();
			}
		});
		
		JButton btnSupprimer = new JButton("Supprimer");
		btnSupprimer.setBounds(156, 308, 110, 25);
		btnSupprimer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				supprimer();
			}
		});
		
		passwordField = new JPasswordField();
		passwordField.setBounds(123, 218, 121, 22);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(256, 18, 392, 260);
		
		JLabel lblId = new JLabel("ID");
		lblId.setBounds(17, 83, 26, 16);
		lblId.setFont(new Font("Tahoma", Font.BOLD, 14));
		
		jtextField_id = new JTextField();
		jtextField_id.setBounds(123, 82, 121, 22);
		jtextField_id.setColumns(10);
		
		JButton btnAfficher = new JButton("Afficher");
		btnAfficher.setBounds(500, 319, 93, 25);
		btnAfficher.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				afficher();
			}
		});
		
		table = new JTable();
		table.setFont(new Font("Tahoma", Font.BOLD, 13));
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null},
			},
			new String[] {
				"ID", "Nom", "Prenom", "Email"
			}
		));
		scrollPane.setViewportView(table);
		
		JLabel label = new JLabel("");
		label.setBounds(0, 0, 660, 436);
		label.setIcon(new ImageIcon("C:\\Users\\Mariam Tiotio Berthe\\Desktop\\java\\workspace eclipse\\mini_projet_java_uml\\images\\notof-mitchell.jpg"));
		label.setBackground(new Color(224, 255, 255));
		contentPane.setLayout(null);
		contentPane.add(lblId);
		contentPane.add(lblNom);
		contentPane.add(lblPrnom);
		contentPane.add(lblEmail);
		contentPane.add(lblMotDePasse);
		contentPane.add(jtextField_id);
		contentPane.add(jtextfile_nom);
		contentPane.add(jtextfile_Prenom);
		contentPane.add(jtextfile_email);
		contentPane.add(passwordField);
		contentPane.add(scrollPane);
		contentPane.add(btnAjouter);
		contentPane.add(btnSupprimer);
		contentPane.add(btnAfficher);
		contentPane.add(label);
		
		JButton btnRetour = new JButton("Retour");
		btnRetour.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Admin admin = new Admin();
				admin.setVisible(true);
				admin.setLocationRelativeTo(null);
				admin.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				OutOffice.this.dispose();
			}
		});
		btnRetour.setBounds(42, 381, 123, 25);
		contentPane.add(btnRetour);
	}

	
	/**R�definition de la methode ajouter de l'interface AddInBd pour l'ajout des donn�es dans la Table account */
	/* (non-Javadoc)
	 * @see DaoFactory.AddInDB#ajouter()
	 */
	@Override
	public void ajouter() {
		
		Connect c = new Connect();
		Connection con = c.connect();
		PreparedStatement pst = null;
		
		String nom= jtextfile_nom.getText();
		String prenom = jtextfile_Prenom.getText();
		String mp =String.valueOf(passwordField.getPassword());
		String email = jtextfile_email.getText();
		Register theRegister = new Register (nom,prenom,email,mp);		
		try {
			pst = con.prepareStatement("INSERT INTO account (Nom,Prenom,Mot_de_Passe,Email) VALUES (?,?,?,?)");
			
			// set params
			pst.setString(1, theRegister.getNom());
			pst.setString(2, theRegister.getPrenom());
			pst.setString(3, theRegister.getMp());
			pst.setString(4, theRegister.getEmail());
			
			
			
			// execute SQL
			pst.executeUpdate();
			//to close 
			pst.close();
			
		} catch (SQLException e) {
		
			e.printStackTrace();
		}
		JOptionPane.showMessageDialog(null,"new member add");
		
		
	}

	@Override
	public void modifier() {
		// TODO Auto-generated method stub
		
	}

	/**r�definition de la methode supprimer de l'interface UpdateInDB pour supprimer un membre  
	 */
	/* (non-Javadoc)
	 * @see DaoFactory.UpdateInDB#supprimer()
	 */
	@Override
	public void supprimer() {
		int id= Integer.parseInt(jtextField_id.getText());
		Accounting account = new Accounting (id);
		Connect c = new Connect();
		Connection con = c.connect();
		PreparedStatement pst = null;

		try {
			
			pst = con.prepareStatement("DELETE FROM `account` WHERE `account`.`ID` = ?");
			//set 
			pst.setInt(1, account.getId());
			//execute
			pst.executeUpdate();
			//close 
			pst.close();
			
		} catch (SQLException e) {e.printStackTrace();} 
		
	}

		
	/**r�definition de la methode afficher de l'interface UpdateInDB pour voir la liste des inscrits dans un jtable  
	 */
	/* (non-Javadoc)
	 * @see DaoFactory.UpdateInDB#afficher()
	 */
	@Override
	public void afficher() {
		Connect c = new Connect();
		Connection con = c.connect();
		PreparedStatement pst = null;
		ResultSet rs = null;
		try {
			pst = con.prepareStatement("SELECT ID,Nom,Prenom,Email FROM account");
			rs = pst.executeQuery();
			table.setModel(DbUtils.resultSetToTableModel(rs));
			
			//close
			pst.close();
			rs.close();
		} catch (SQLException e) {e.printStackTrace();}
		
	}
}
