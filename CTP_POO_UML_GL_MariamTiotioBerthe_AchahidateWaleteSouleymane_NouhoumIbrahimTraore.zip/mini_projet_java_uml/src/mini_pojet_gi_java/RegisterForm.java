package mini_pojet_gi_java;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;

import connectionDAO.AddInDB;
import connectionDAO.Connect;
import daodata.Accounting;
import daodata.Register;
import java.awt.Color;
import java.awt.Cursor;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class RegisterForm extends JFrame implements AddInDB {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JPasswordField passwordField;
	private JTextField jtextfile_nom;
	private JTextField jtextfile_nomUtilisateur;
	private JTextField jtextfile_email;
	private JTextField jtextfile_niveau;
	private JTextField jtextfile_tel;
	private JTextField jtextfile_Prenom;
	
	
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RegisterForm frame = new RegisterForm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public RegisterForm() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 549, 544);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setUndecorated(true);
		this.setLocationRelativeTo(null);
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(new Color(245, 245, 220));
		panel.setBounds(0, 0, 548, 62);
		contentPane.add(panel);
		
		JLabel lblInscription = new JLabel("Inscription");
		lblInscription.setForeground(Color.WHITE);
		lblInscription.setFont(new Font("Tahoma", Font.BOLD, 30));
		lblInscription.setBounds(185, 13, 177, 44);
		panel.add(lblInscription);
		
		JLabel jlabel_close = new JLabel("X");
		jlabel_close.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		jlabel_close.addMouseListener(new MouseAdapter() {
			
			@Override
			public void mouseExited(MouseEvent e) {
				Border label_border = BorderFactory.createMatteBorder(1, 1, 1, 1, Color.black);
				jlabel_close.setBorder(label_border);
				jlabel_close.setForeground(Color.black);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				Border label_border = BorderFactory.createMatteBorder(1, 1, 1, 1, Color.red);
				jlabel_close.setBorder(label_border);
				jlabel_close.setForeground(Color.red);
			}
			
			@Override
			public void mouseClicked(MouseEvent arg0) {
				
				System.exit(0);
			}
		});
		jlabel_close.setForeground(Color.BLACK);
		jlabel_close.setFont(new Font("Tahoma", Font.BOLD, 30));
		jlabel_close.setBounds(515, 13, 28, 44);
		panel.add(jlabel_close);
		
		JLabel jlabel_minimize = new JLabel("-");
		jlabel_minimize.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		jlabel_minimize.addMouseListener(new MouseAdapter() {
			
			@Override
			public void mouseExited(MouseEvent e) {
				Border label_border = BorderFactory.createMatteBorder(1, 1, 1, 1, Color.black);
				jlabel_minimize.setBorder(label_border);
				jlabel_minimize.setForeground(Color.black);
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				Border label_border = BorderFactory.createMatteBorder(1, 1, 1, 1, Color.white);
				jlabel_minimize.setBorder(label_border);
				jlabel_minimize.setForeground(Color.white);
			}
			
			@Override
			public void mouseClicked(MouseEvent e) {
				
				RegisterForm.this.setState(JFrame.ICONIFIED);
			}

		});
		jlabel_minimize.setForeground(Color.BLACK);
		jlabel_minimize.setFont(new Font("Tahoma", Font.BOLD, 30));
		jlabel_minimize.setBounds(475, 13, 28, 44);
		panel.add(jlabel_minimize);
		
		JPanel panel_1 = new JPanel();
		panel_1.setLayout(null);
		panel_1.setBackground(new Color(119, 181, 254));
		panel_1.setBounds(0, 66, 548, 479);
		contentPane.add(panel_1);
		
		JButton jbutton_back = new JButton("Retour");
		jbutton_back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Login l = new Login();
				l.setVisible(true);
				l.setLocationRelativeTo(null);
				l.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				RegisterForm.this.dispose();
			}
		});
		jbutton_back.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		jbutton_back.setForeground(Color.WHITE);
		jbutton_back.setFont(new Font("Tahoma", Font.BOLD, 16));
		jbutton_back.setBackground(new Color(195, 57, 43));
		jbutton_back.setBounds(237, 388, 107, 26);
		panel_1.add(jbutton_back);
		
		JButton jbutton_add = new JButton("Ajouter");
		jbutton_add.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent arg0) {
				//appel de la methode saveemployer pour le stockage dans la base de donn�e
				ajouter();
							
			}
		});
		
		
		jbutton_back.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		jbutton_add.setForeground(Color.WHITE);
		jbutton_add.setFont(new Font("Tahoma", Font.BOLD, 16));
		jbutton_add.setBackground(new Color(34, 167, 240));
		jbutton_add.setBounds(367, 387, 97, 29);
		panel_1.add(jbutton_add);
		
		JLabel lblCliquezIciPour = new JLabel("Cliquez ici pour se connecter");
		lblCliquezIciPour.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				Login l = new Login();
				l.setVisible(true);
				//register.pack();
				l.setLocationRelativeTo(null);
				l.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				RegisterForm.this.dispose();
			
			}
		});
		lblCliquezIciPour.setForeground(Color.WHITE);
		lblCliquezIciPour.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblCliquezIciPour.setBounds(248, 440, 226, 26);
		panel_1.add(lblCliquezIciPour);
		
		JLabel lblNomEtPrenom = new JLabel("Nom :");
		lblNomEtPrenom.setForeground(new Color(236, 240, 241));
		lblNomEtPrenom.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNomEtPrenom.setBounds(42, 22, 159, 16);
		panel_1.add(lblNomEtPrenom);
		
		JLabel jlabel_nomUtilisateur = new JLabel("Nom d'utilisateur :");
		jlabel_nomUtilisateur.setForeground(new Color(236, 240, 241));
		jlabel_nomUtilisateur.setFont(new Font("Tahoma", Font.BOLD, 16));
		jlabel_nomUtilisateur.setBounds(42, 121, 159, 16);
		panel_1.add(jlabel_nomUtilisateur);
		
		JLabel jlabel_motDePasse = new JLabel("Mot de passe :");
		jlabel_motDePasse.setForeground(new Color(236, 240, 241));
		jlabel_motDePasse.setFont(new Font("Tahoma", Font.BOLD, 16));
		jlabel_motDePasse.setBounds(44, 167, 127, 16);
		panel_1.add(jlabel_motDePasse);
		
		passwordField = new JPasswordField("");
		passwordField.setForeground(Color.BLACK);
		passwordField.setFont(new Font("Tahoma", Font.PLAIN, 16));
		passwordField.setBackground(Color.WHITE);
		passwordField.setBounds(244, 158, 274, 34);
		panel_1.add(passwordField);
		
		JLabel jlabel_cin = new JLabel("E-Mail :");
		jlabel_cin.setForeground(new Color(236, 240, 241));
		jlabel_cin.setFont(new Font("Tahoma", Font.BOLD, 16));
		jlabel_cin.setBounds(45, 214, 70, 16);
		panel_1.add(jlabel_cin);
		
		JLabel jlabel_filiere = new JLabel("Niveau :");
		jlabel_filiere.setForeground(new Color(236, 240, 241));
		jlabel_filiere.setFont(new Font("Tahoma", Font.BOLD, 16));
		jlabel_filiere.setBounds(42, 266, 159, 16);
		panel_1.add(jlabel_filiere);
		
		JLabel jlabel_tel = new JLabel("Tel :");
		jlabel_tel.setForeground(new Color(236, 240, 241));
		jlabel_tel.setFont(new Font("Tahoma", Font.BOLD, 16));
		jlabel_tel.setBounds(51, 319, 159, 16);
		panel_1.add(jlabel_tel);
		
		jtextfile_nom = new JTextField();
		jtextfile_nom.setFont(new Font("Tahoma", Font.PLAIN, 16));
		jtextfile_nom.setBounds(244, 13, 274, 34);
		panel_1.add(jtextfile_nom);
		jtextfile_nom.setColumns(10);
		
		jtextfile_nomUtilisateur = new JTextField();
		jtextfile_nomUtilisateur.setFont(new Font("Tahoma", Font.PLAIN, 16));
		jtextfile_nomUtilisateur.setColumns(10);
		jtextfile_nomUtilisateur.setBounds(244, 111, 274, 34);
		panel_1.add(jtextfile_nomUtilisateur);
		
		jtextfile_email = new JTextField();
		jtextfile_email.setFont(new Font("Tahoma", Font.PLAIN, 16));
		jtextfile_email.setColumns(10);
		jtextfile_email.setBounds(244, 205, 274, 34);
		panel_1.add(jtextfile_email);
		
		jtextfile_niveau = new JTextField();
		jtextfile_niveau.setFont(new Font("Tahoma", Font.PLAIN, 16));
		jtextfile_niveau.setColumns(10);
		jtextfile_niveau.setBounds(244, 252, 274, 34);
		panel_1.add(jtextfile_niveau);
		
		jtextfile_tel = new JTextField();
		jtextfile_tel.setFont(new Font("Tahoma", Font.PLAIN, 16));
		jtextfile_tel.setColumns(10);
		jtextfile_tel.setBounds(244, 310, 274, 34);
		panel_1.add(jtextfile_tel);
		
		JLabel lblPrenom = new JLabel("Prenom :");
		lblPrenom.setForeground(new Color(236, 240, 241));
		lblPrenom.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblPrenom.setBounds(42, 73, 159, 16);
		panel_1.add(lblPrenom);
		
		jtextfile_Prenom = new JTextField();
		jtextfile_Prenom.setFont(new Font("Tahoma", Font.PLAIN, 16));
		jtextfile_Prenom.setColumns(10);
		jtextfile_Prenom.setBounds(244, 64, 274, 34);
		panel_1.add(jtextfile_Prenom);
	}

	/**R�definition de la methode ajouter de l'interface AddInBd pour l'ajout des donn�es dans les
	 * Tables account et comptabilit� */
	@Override
	public void ajouter() {
		
		Connect c = new Connect();
		Connection con = c.connect();
		PreparedStatement pst = null;
		
		String nom= jtextfile_nom.getText();
		String prenom = jtextfile_Prenom.getText();
		String nu = jtextfile_nomUtilisateur.getText(); 
		String mp =String.valueOf(passwordField.getPassword());
		String email = jtextfile_email.getText();
		String niv= jtextfile_niveau.getText();
		String tel= jtextfile_tel.getText();
		
		Register theRegister = new Register (nom,prenom,nu,mp,email,niv,tel);		
		try {
			pst = con.prepareStatement("INSERT INTO account (Nom,Prenom,Nom_Utilisateur,Mot_de_Passe,Email,Niveau,Tel) VALUES (?,?,?,?,?,?,?)");
			
			// set params
			pst.setString(1, theRegister.getNom());
			pst.setString(2, theRegister.getPrenom());
			pst.setString(3, theRegister.getNu());
			pst.setString(4, theRegister.getMp());
			pst.setString(5, theRegister.getEmail());
			pst.setString(6, theRegister.getNiv());
			pst.setString(7, theRegister.getTel());
			
			// execute SQL
			pst.executeUpdate();
			//to close 
			pst.close();
			
		} catch (SQLException e) {
		
			e.printStackTrace();
		}
		JOptionPane.showMessageDialog(null,"new member add");
		// l'ajout � la table comptabilit�
		String Nu = jtextfile_nomUtilisateur.getText();
		String Email = jtextfile_email.getText();
		String Tel= jtextfile_tel.getText();
		Accounting account = new Accounting (Nu,Email,Tel,"");
		
		try {
			pst = con.prepareStatement("INSERT INTO comptabilit� (Nom_Utilisateur,Email,Tel,Montant) VALUES (?,?,?,?)");
			
			// set params
			pst.setString(1, account.getNu());
			pst.setString(2, account.getEmail());
			pst.setString(3, account.getTel());
			pst.setString(4, account.getMontant());
			pst.executeUpdate();
			
			pst.close();
		} catch (SQLException e) {

			e.printStackTrace();
		}
	}
}
