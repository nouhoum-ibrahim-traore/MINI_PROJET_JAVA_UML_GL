package mini_pojet_gi_java;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import connectionDAO.Connect;
import connectionDAO.UpdateInDB;

import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;

import daodata.NewPassword;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
/**
 * @author Mariam Tiotio Berthe
 * @author Nouhoum Ibrahim Traore
 * @author Achahidat Wallet Souleymane
 * 
 * Class qui herite de jframe et qui implemente l'interface updateInDB pour
 * la modification dumot de passe dans la base de donn�e
	 */
public class ForGotPassword extends JFrame implements UpdateInDB {

	
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField_Email;
	private JPasswordField new_passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ForGotPassword frame = new ForGotPassword();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ForGotPassword() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 497, 262);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		setUndecorated(true);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(new Color(44, 62, 80));
		panel.setBounds(0, 0, 497, 262);
		contentPane.add(panel);
		
		JLabel lblCin = new JLabel("Email :");
		lblCin.setForeground(new Color(236, 240, 241));
		lblCin.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblCin.setBounds(103, 90, 66, 16);
		panel.add(lblCin);
		
		JLabel lblNouveauMotDe = new JLabel("Nouveau Mot de passe :");
		lblNouveauMotDe.setForeground(new Color(236, 240, 241));
		lblNouveauMotDe.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNouveauMotDe.setBounds(29, 137, 209, 16);
		panel.add(lblNouveauMotDe);
		
		textField_Email = new JTextField();
		textField_Email.setForeground(Color.WHITE);
		textField_Email.setFont(new Font("Tahoma", Font.PLAIN, 16));
		textField_Email.setColumns(10);
		textField_Email.setBackground(new Color(108, 122, 137));
		textField_Email.setBounds(250, 85, 208, 26);
		panel.add(textField_Email);
		
		new_passwordField = new JPasswordField("");
		new_passwordField.setForeground(Color.WHITE);
		new_passwordField.setFont(new Font("Tahoma", Font.PLAIN, 16));
		new_passwordField.setBackground(new Color(108, 122, 137));
		new_passwordField.setBounds(250, 132, 208, 26);
		panel.add(new_passwordField);
		
		JButton btnOk = new JButton("OK");
		btnOk.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnOk.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				modifier();
				
			}
		});
		btnOk.setForeground(Color.WHITE);
		btnOk.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnOk.setBackground(new Color(34, 167, 240));
		btnOk.setBounds(318, 182, 78, 37);
		panel.add(btnOk);
		
		JLabel jlabel_exit = new JLabel("X");
		jlabel_exit.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		jlabel_exit.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				
				System.exit(0);
			}
		});
		jlabel_exit.setForeground(Color.RED);
		jlabel_exit.setFont(new Font("Tahoma", Font.BOLD, 30));
		jlabel_exit.setBounds(457, 13, 21, 37);
		panel.add(jlabel_exit);
		
		JLabel label_minimize = new JLabel("-");
		label_minimize.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		label_minimize.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				ForGotPassword.this.setState(JFrame.ICONIFIED);
			}
		});
		label_minimize.setForeground(Color.WHITE);
		label_minimize.setFont(new Font("Tahoma", Font.BOLD, 30));
		label_minimize.setBounds(413, 13, 28, 44);
		panel.add(label_minimize);
		
		JButton btnRetour = new JButton("Retour ");
		btnRetour.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Login log = new Login();
				log.setVisible(true);
				log.setLocationRelativeTo(null);
				log.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				ForGotPassword.this.dispose();
			}
		});
		btnRetour.setForeground(Color.WHITE);
		btnRetour.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnRetour.setBackground(new Color(34, 167, 240));
		btnRetour.setBounds(40, 182, 106, 37);
		panel.add(btnRetour);
		this.setLocationRelativeTo(null);
	}
	
/**r�d�finition de la m�thode modifier*/

	@Override
	public void modifier() {
		
		String newpwd= String.valueOf(new_passwordField.getPassword());
		String Email = textField_Email.getText();
		NewPassword theNewPassword = new NewPassword(newpwd,Email);
		Connect c = new Connect();
		Connection con = c.connect();
		PreparedStatement pst = null;
		ResultSet rs =null;
		
		try {
			pst = con.prepareStatement("SELECT * FROM `account` WHERE  Email= ?");
			pst.setString(1, theNewPassword.getEmail());
			rs = pst.executeQuery();
			
			if(rs.next()) {
				if (rs.getString("Email").equals(Email)) {
					try {
						pst = con.prepareStatement("UPDATE account SET Mot_de_Passe = ? WHERE account.Email = ?");
						
						pst.setString(1, theNewPassword.getPwd());
						pst.setString(2, theNewPassword.getEmail());
						
						pst.executeUpdate();
					} catch (SQLException e) {e.printStackTrace();}
					}
			}
			else {
				try {
					PreparedStatement preparedStatement = pst = con.prepareStatement("SELECT * FROM `Membre_Bureau` WHERE  Email= ?");
					pst.setString(1, theNewPassword.getEmail());
					rs = pst.executeQuery();
					
					
					if(rs.next()) {
						if (rs.getString("Email").equals(Email)) {
							try {
								pst = con.prepareStatement("UPDATE account SET mot_de_passe = ? WHERE Membre_Bureau.Email = ?");
								
								pst.setString(1, theNewPassword.getPwd());
								pst.setString(2, theNewPassword.getEmail());
								
								pst.executeUpdate();
							} catch (SQLException e) {e.printStackTrace();}
							}
						}
					}catch (SQLException e1) {e1.printStackTrace();}
			}
		} catch (SQLException e1) {e1.printStackTrace();}
			
		
	}

	@Override
	public void supprimer() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void afficher() {
		// TODO Auto-generated method stub
		
	}
}
