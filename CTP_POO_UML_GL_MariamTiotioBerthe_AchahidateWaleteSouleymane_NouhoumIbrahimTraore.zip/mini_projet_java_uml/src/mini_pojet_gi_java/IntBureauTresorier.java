package mini_pojet_gi_java;


import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;


import mini_pojet_gi_java.AccountingForm;
import mini_pojet_gi_java.Login;

import javax.swing.GroupLayout;
import javax.swing.ImageIcon;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;

import javax.swing.JLabel;
/**
 * @author Mariam Tiotio Berthe
* @author Nouhoum Ibrahim Traore
* @author Achahidat Wallet Souleymane
* 
* classe qui h�rute de jFrame 
* interface user tresorier
 */
public class IntBureauTresorier extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					IntBureauTresorier frame = new IntBureauTresorier();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public IntBureauTresorier() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 315);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(250, 250, 210));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		this.setLocationRelativeTo(null);
		
		JButton btnProfil = new JButton("Profil");
		btnProfil.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Profil2 user = new Profil2();
				user.setVisible(true);
				user.setLocationRelativeTo(null);
				user.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				IntBureauTresorier.this.dispose();
			}
		});
		btnProfil.setBackground(Color.WHITE);
		btnProfil.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnProfil.setForeground(Color.ORANGE);
		
		JButton btnEvnement = new JButton("Ev\u00E9nement");
		btnEvnement.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Event2 even = new Event2();
				even.setVisible(true);
				even.setLocationRelativeTo(null);
				even.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				IntBureauTresorier.this.dispose();
			}
		});
		btnEvnement.setBackground(Color.WHITE);
		btnEvnement.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnEvnement.setForeground(Color.ORANGE);
		
		JButton btnTrsorrie = new JButton("Tr\u00E9sorerie");
		btnTrsorrie.setBackground(Color.WHITE);
		btnTrsorrie.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnTrsorrie.setForeground(Color.ORANGE);
		btnTrsorrie.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				AccountingForm t = new AccountingForm();
				t.setVisible(true);
				t.setLocationRelativeTo(null);
				t.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				IntBureauTresorier.this.dispose();
			}
		});
		
		JLabel lblNewLabel = new JLabel("Bienvenue!");
		lblNewLabel.setForeground(Color.ORANGE);
		lblNewLabel.setFont(new Font("Script MT Bold", Font.BOLD | Font.ITALIC, 25));
		lblNewLabel.setBackground(Color.WHITE);
		
		JLabel lblNewLabel_1 = new JLabel("");
		Image img2 = new ImageIcon(this.getClass().getResource("/prof.png")).getImage();
		lblNewLabel_1.setIcon(new ImageIcon(img2));
		
		
		JLabel lblNewLabel_2 = new JLabel("");
		Image img1 = new ImageIcon(this.getClass().getResource("/event1.png")).getImage();
		lblNewLabel_2.setIcon(new ImageIcon(img1));
		
		JLabel lblNewLabel_3 = new JLabel("");
		Image img3 = new ImageIcon(this.getClass().getResource("/treasure.png")).getImage();
		lblNewLabel_3.setIcon(new ImageIcon(img3));
		
		JButton button = new JButton("D\u00E9connexion");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Login log = new Login();
				log.setVisible(true);
				log.setLocationRelativeTo(null);
				log.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				IntBureauTresorier.this.dispose();
			}
		});
		button.setForeground(Color.WHITE);
		button.setFont(new Font("Tahoma", Font.BOLD, 11));
		button.setBackground(Color.ORANGE);
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(132)
							.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 161, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(btnProfil)
								.addComponent(lblNewLabel_1, GroupLayout.PREFERRED_SIZE, 72, GroupLayout.PREFERRED_SIZE))
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addPreferredGap(ComponentPlacement.RELATED, 70, Short.MAX_VALUE)
									.addComponent(lblNewLabel_3, GroupLayout.PREFERRED_SIZE, 110, GroupLayout.PREFERRED_SIZE)
									.addGap(27))
								.addGroup(gl_contentPane.createSequentialGroup()
									.addGap(52)
									.addComponent(btnTrsorrie)
									.addPreferredGap(ComponentPlacement.RELATED)))
							.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING, false)
								.addComponent(lblNewLabel_2, GroupLayout.PREFERRED_SIZE, 83, GroupLayout.PREFERRED_SIZE)
								.addComponent(button, GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE)
								.addComponent(btnEvnement, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
					.addGap(24))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 61, GroupLayout.PREFERRED_SIZE)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(32)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(lblNewLabel_1, GroupLayout.PREFERRED_SIZE, 86, GroupLayout.PREFERRED_SIZE)
									.addGap(18))
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(lblNewLabel_2, GroupLayout.DEFAULT_SIZE, 98, Short.MAX_VALUE)
									.addPreferredGap(ComponentPlacement.RELATED))))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(lblNewLabel_3, GroupLayout.PREFERRED_SIZE, 58, GroupLayout.PREFERRED_SIZE)
							.addGap(30)))
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
							.addComponent(btnProfil)
							.addComponent(btnTrsorrie))
						.addComponent(btnEvnement))
					.addGap(8)
					.addComponent(button))
		);
		contentPane.setLayout(gl_contentPane);
	}
}
