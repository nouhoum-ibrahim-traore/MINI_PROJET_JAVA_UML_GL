package mini_pojet_gi_java;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import connectionDAO.AddInDB;
import connectionDAO.Connect;
import connectionDAO.UpdateInDB;
import daodata.Accounting;
import net.proteanit.sql.DbUtils;

import javax.swing.JButton;
import java.awt.event.ActionListener;

import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.JTextField;


/**
 * @author Mariam Tiotio Berthe
 * @author Nouhoum Ibrahim Traore
 * @author Achahidat Wallet Souleymane
 *Class qui herite de jframe et qui implemente les interfaces pour l'ajout,
 * l'affichage la modification et la suppression dans la base de donn�e
 */
public class AccountingForm extends JFrame implements AddInDB, UpdateInDB {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable table;
	private JTextField jtextfile_nomUtilisateur;
	private JTextField jtextfile_email;
	private JTextField jtextfile_tel;
	private JTextField jtextField_montant;
	private JTextField jtextField_id;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AccountingForm frame = new AccountingForm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	/**
	 * 
	 */
	/**
	 * 
	 */
	public AccountingForm() {
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 947, 425);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		this.setLocationRelativeTo(null);
		
		JLabel lblNomDuGroupe = new JLabel("Comptabilit\u00E9 : ");
		lblNomDuGroupe.setBounds(240, 13, 138, 22);
		lblNomDuGroupe.setFont(new Font("Tahoma", Font.BOLD, 16));
		contentPane.add(lblNomDuGroupe);
		
				
		JButton btnAfficher = new JButton("Afficher");
		btnAfficher.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				afficher();
				
			}
		});
		btnAfficher.setBounds(571, 13, 97, 25);
		contentPane.add(btnAfficher);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(335, 68, 508, 226);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		JButton btnNewButton = new JButton("Ajouter");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ajouter();
			}
		});
		btnNewButton.setBounds(94, 220, 127, 22);
		contentPane.add(btnNewButton);
		
		JLabel lblNom = new JLabel("Nom :");
		lblNom.setForeground(Color.BLACK);
		lblNom.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNom.setBounds(12, 86, 70, 16);
		contentPane.add(lblNom);
		
		jtextfile_nomUtilisateur = new JTextField();
		jtextfile_nomUtilisateur.setFont(new Font("Tahoma", Font.PLAIN, 14));
		jtextfile_nomUtilisateur.setColumns(10);
		jtextfile_nomUtilisateur.setBounds(94, 83, 158, 22);
		contentPane.add(jtextfile_nomUtilisateur);
		
		JLabel lblEmail = new JLabel("Email :");
		lblEmail.setForeground(Color.BLACK);
		lblEmail.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblEmail.setBounds(12, 115, 70, 16);
		contentPane.add(lblEmail);
		
		jtextfile_email = new JTextField();
		jtextfile_email.setFont(new Font("Tahoma", Font.PLAIN, 14));
		jtextfile_email.setColumns(10);
		jtextfile_email.setBounds(94, 112, 158, 22);
		contentPane.add(jtextfile_email);
		
		jtextfile_tel = new JTextField();
		jtextfile_tel.setFont(new Font("Tahoma", Font.PLAIN, 14));
		jtextfile_tel.setColumns(10);
		jtextfile_tel.setBounds(94, 147, 158, 22);
		contentPane.add(jtextfile_tel);
		
		JLabel lblMontant = new JLabel("Tel :");
		lblMontant.setForeground(Color.BLACK);
		lblMontant.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblMontant.setBounds(12, 150, 84, 16);
		contentPane.add(lblMontant);
		
		JLabel lblMontant_1 = new JLabel("Montant :");
		lblMontant_1.setForeground(Color.BLACK);
		lblMontant_1.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblMontant_1.setBounds(12, 185, 84, 16);
		contentPane.add(lblMontant_1);
		
		jtextField_montant = new JTextField();
		jtextField_montant.setFont(new Font("Tahoma", Font.PLAIN, 14));
		jtextField_montant.setColumns(10);
		jtextField_montant.setBounds(94, 182, 158, 22);
		contentPane.add(jtextField_montant);
		
		JLabel lblId = new JLabel("ID :");
		lblId.setForeground(Color.BLACK);
		lblId.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblId.setBounds(12, 51, 70, 16);
		contentPane.add(lblId);
		
		jtextField_id = new JTextField();
		jtextField_id.setFont(new Font("Tahoma", Font.PLAIN, 14));
		jtextField_id.setColumns(10);
		jtextField_id.setBounds(94, 48, 158, 22);
		contentPane.add(jtextField_id);
		
		JButton btnModifier = new JButton("Ajouter Montant");
		btnModifier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				modifier();
			}
		});
		btnModifier.setBounds(94, 261, 127, 22);
		contentPane.add(btnModifier);
		
		JButton btnSupprimer = new JButton("Supprimer");
		btnSupprimer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				supprimer();
			}
		});
		btnSupprimer.setBounds(725, 329, 127, 22);
		contentPane.add(btnSupprimer);
		
		JButton btnRetour = new JButton("Retour");
		btnRetour.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				IntBureauTresorier even = new IntBureauTresorier();
				even.setVisible(true);
				even.setLocationRelativeTo(null);
				even.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				AccountingForm.this.dispose();
			}
		});
		btnRetour.setBounds(94, 329, 127, 22);
		contentPane.add(btnRetour);
	}
	
	public void addRow( String cin,String nu,String tel) {
		DefaultTableModel model = (DefaultTableModel)table.getModel(); 
		model.addRow(new Object[] {cin, nu, tel});
		
	}

	/**r�d�finition de la methode de l'interface AddInDB pour ajouter les donn�es dans la table comptabilit�*/
	@Override
	public void ajouter() {
		String nu = jtextfile_nomUtilisateur.getText();
		String email = jtextfile_email.getText();
		String tel= jtextfile_tel.getText();
		String montant= jtextField_montant.getText();
		Accounting account = new Accounting (nu,email,tel,montant);
		Connect c = new Connect();
		Connection con = c.connect();
		PreparedStatement pst = null;
		
		
				
		try {
			pst = con.prepareStatement("INSERT INTO comptabilit� (Nom_Utilisateur,Email,Tel,Montant) VALUES (?,?,?,?)");
			
			// set params
			pst.setString(1, account.getNu());
			pst.setString(2, account.getEmail());
			pst.setString(3, account.getTel());
			pst.setString(4, account.getMontant());
			pst.executeUpdate();
			
			pst.close();
		} catch (SQLException e) {

			e.printStackTrace();
		}
		
		JOptionPane.showMessageDialog(null,"Ajout r�ussi !!!");
	
		
	}
	
	
	/**r�definition de la methode modifier de l'interface UpdateInDB pour la modification dans la base de 
	 * de donn�e*/
	@Override
	public void modifier() {
		
		int id= Integer.parseInt(jtextField_id.getText());
		String montant= jtextField_montant.getText();
		Accounting account = new Accounting (montant,id);
		Connect c = new Connect();
		Connection con = c.connect();
		PreparedStatement pst = null;

		try {
			
			pst = con.prepareStatement("UPDATE comptabilit� SET Montant = ? WHERE comptabilit�.id = ?");
			//set 
			pst.setString(1, account.getMontant());
			pst.setInt(2, account.getId());
			//execute
			pst.executeUpdate();
			//close 
			pst.close();
			
		} catch (SQLException e) {e.printStackTrace();} 
		
	}

	@Override
	public void supprimer() {
		int id= Integer.parseInt(jtextField_id.getText());
		Accounting account = new Accounting (id);
		Connect c = new Connect();
		Connection con = c.connect();
		PreparedStatement pst = null;

		try {
			
			pst = con.prepareStatement("DELETE FROM `comptabilit�` WHERE `comptabilit�`.`ID` = ?");
			//set 
			pst.setInt(1, account.getId());
			//execute
			pst.executeUpdate();
			//close 
			pst.close();
			
		} catch (SQLException e) {e.printStackTrace();} 
		
		
		
	}

	/**r�definition de la methode afficher de l'interface UpdateInDB pour voir la liste de comptabilit�  dans un jtable  
	 */
	/* (non-Javadoc)
	 * @see DaoFactory.UpdateInDB#afficher()
	 */
	@Override
	public void afficher() {
		
		Connect c = new Connect();
		Connection con = c.connect();
		PreparedStatement pst = null;
		ResultSet rs = null;
		try {
			pst = con.prepareStatement("SELECT * FROM comptabilit�");
			rs = pst.executeQuery();
			table.setModel(DbUtils.resultSetToTableModel(rs));
			
			//close
			pst.close();
			rs.close();
		} catch (SQLException e) {e.printStackTrace();}
		
		
	}
	 




}
