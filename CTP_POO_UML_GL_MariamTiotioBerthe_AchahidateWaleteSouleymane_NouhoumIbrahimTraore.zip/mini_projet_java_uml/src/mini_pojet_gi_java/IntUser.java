package mini_pojet_gi_java;


import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class IntUser extends JFrame {

	/**
	 * @author Mariam Tiotio Berthe
 * @author Nouhoum Ibrahim Traore
 * @author Achahidat Wallet Souleymane
 * 
 * classe qui h�rute de jFrame 
 * interface user
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					IntUser frame = new IntUser();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public IntUser() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 640, 380);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(250, 250, 210));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		this.setLocationRelativeTo(null);
		
		JButton jbutton_Profil = new JButton("Profile");
		jbutton_Profil.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				IntUserProfil profil = new IntUserProfil();
				profil.setVisible(true);
				profil.setLocationRelativeTo(null);
				profil.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				IntUser.this.dispose();
			}
		});
		jbutton_Profil.setForeground(Color.WHITE);
		jbutton_Profil.setFont(new Font("Tahoma", Font.BOLD, 11));
		jbutton_Profil.setBackground(Color.ORANGE);
		
		JButton jbutton_Evnements = new JButton("Ev\u00E9nements");
		jbutton_Evnements.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Event1 even = new Event1();
				even.setVisible(true);
				even.setLocationRelativeTo(null);
				even.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				IntUser.this.dispose();
			}
		});
		jbutton_Evnements.setBackground(Color.ORANGE);
		jbutton_Evnements.setForeground(Color.WHITE);
		jbutton_Evnements.setFont(new Font("Tahoma", Font.BOLD, 11));
		
		
		
		JLabel lblNewLabel_1 = new JLabel("");
		Image img = new ImageIcon(this.getClass().getResource("/event1.png")).getImage();
		lblNewLabel_1.setIcon(new ImageIcon(img));
		
		JLabel lblBienvenue = new JLabel("Bienvenue!");
		lblBienvenue.setForeground(Color.ORANGE);
		lblBienvenue.setBackground(Color.ORANGE);
		lblBienvenue.setFont(new Font("Script MT Bold", Font.BOLD | Font.ITALIC, 30));
		
		JLabel lblNewLabel = new JLabel("");
		Image img2 = new ImageIcon(this.getClass().getResource("/prof.png")).getImage();
		lblNewLabel.setIcon(new ImageIcon(img2));
		
		JLabel lblNewLabel_2 = new JLabel("");
		Image img3 = new ImageIcon(this.getClass().getResource("/event1.png")).getImage();
		lblNewLabel_2.setIcon(new ImageIcon(img3));
		
		JButton jbutton_Deconnexion = new JButton("D\u00E9connexion");
		jbutton_Deconnexion.setForeground(Color.WHITE);
		jbutton_Deconnexion.setFont(new Font("Tahoma", Font.BOLD, 11));
		jbutton_Deconnexion.setBackground(Color.ORANGE);
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(24)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(164)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(lblNewLabel_1, GroupLayout.PREFERRED_SIZE, 222, GroupLayout.PREFERRED_SIZE)
									.addContainerGap())
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(lblBienvenue, GroupLayout.DEFAULT_SIZE, 339, Short.MAX_VALUE)
									.addGap(87))))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 124, GroupLayout.PREFERRED_SIZE)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(jbutton_Profil, GroupLayout.DEFAULT_SIZE, 86, Short.MAX_VALUE)
									.addGap(38)))
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addGap(313)
									.addComponent(lblNewLabel_2, GroupLayout.PREFERRED_SIZE, 113, GroupLayout.PREFERRED_SIZE))
								.addGroup(gl_contentPane.createSequentialGroup()
									.addGap(282)
									.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
										.addComponent(jbutton_Deconnexion, GroupLayout.PREFERRED_SIZE, 111, GroupLayout.PREFERRED_SIZE)
										.addComponent(jbutton_Evnements, GroupLayout.PREFERRED_SIZE, 111, GroupLayout.PREFERRED_SIZE))))
							.addGap(40))))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(79)
							.addComponent(lblBienvenue, GroupLayout.PREFERRED_SIZE, 47, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
							.addComponent(lblNewLabel_1, GroupLayout.PREFERRED_SIZE, 0, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(lblNewLabel_2, GroupLayout.PREFERRED_SIZE, 78, GroupLayout.PREFERRED_SIZE)
							.addGap(46))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addContainerGap()
							.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 87, GroupLayout.PREFERRED_SIZE)
							.addGap(18)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
								.addComponent(jbutton_Profil)
								.addComponent(jbutton_Evnements, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
							.addPreferredGap(ComponentPlacement.RELATED)))
					.addGap(11)
					.addComponent(jbutton_Deconnexion))
		);
		contentPane.setLayout(gl_contentPane);
	}
}
