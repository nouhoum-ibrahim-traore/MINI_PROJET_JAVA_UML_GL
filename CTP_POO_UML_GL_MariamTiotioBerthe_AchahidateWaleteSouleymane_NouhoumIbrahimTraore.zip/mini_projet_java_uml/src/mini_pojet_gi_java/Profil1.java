package mini_pojet_gi_java;


import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import connectionDAO.Connect;
import connectionDAO.UpdateInDB;
import daodata.Register;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import javax.swing.JButton;
import java.awt.Color;

import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import java.awt.Font;

/**
 * @author Mariam Tiotio Berthe
 * @author Nouhoum Ibrahim Traore
 * @author Achahidat Wallet Souleymane
 * 
 * Class qui herite de jframe et qui implemente les interfaces pour l'ajout,
 * l'affichage la modification et la suppression dans la base de donn�e
 *Elle permettra � l'utilisateur de modifier,supprimer, son profil
 *
 */
public class Profil1 extends JFrame implements UpdateInDB {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField_prenom;
	private JTextField textField_nom;
	private JTextField textField_email;
	private JPasswordField passwordField;
	private JButton btnModifier;
	private JButton btnSupprimer;
	private JLabel lblNewLabel;
	private JTextField jtextField_niveau;
	private JLabel lblNiveau;
	private JLabel lblTel;
	private JTextField jtextField_tel;
	private JTextField textField_email_1;
	private JTextField textField_utilisateur;
	private JLabel lblUtilisateur;
	private JLabel lblAncienEmail;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Profil1 frame = new Profil1();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Profil1() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 629, 456);
		contentPane = new JPanel();
		contentPane.setToolTipText("Bienvenue!");
		contentPane.setBackground(new Color(250, 250, 210));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		this.setLocationRelativeTo(null);
		
		JLabel lblNom = new JLabel("Nom");
		lblNom.setForeground(Color.ORANGE);
		lblNom.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 11));
		
		JLabel lblPrnom = new JLabel("Pr\u00E9nom");
		lblPrnom.setForeground(Color.ORANGE);
		lblPrnom.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 11));
		
		JLabel lblEmail = new JLabel("E-mail");
		lblEmail.setForeground(Color.ORANGE);
		lblEmail.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 11));
		
		JLabel lblMotDePasse = new JLabel("Mot de passe");
		lblMotDePasse.setForeground(Color.ORANGE);
		lblMotDePasse.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 11));
		
		textField_prenom = new JTextField();
		textField_prenom.setColumns(10);
		
		textField_nom = new JTextField();
		textField_nom.setColumns(10);
		
		textField_email = new JTextField();
		textField_email.setColumns(10);
		
		passwordField = new JPasswordField();
		
		
		
		btnModifier = new JButton("Modifier");
		btnModifier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				modifier();
			}
		});
		btnModifier.setForeground(Color.ORANGE);
		btnModifier.setFont(new Font("Tahoma", Font.BOLD, 11));
		Image img2 = new ImageIcon(this.getClass().getResource("/refresh.png")).getImage();
		btnModifier.setIcon(new ImageIcon(img2));
		btnModifier.setBackground(Color.WHITE);
		
	;
		
		btnSupprimer = new JButton("Supprimer");
		btnSupprimer.setForeground(Color.ORANGE);
		btnSupprimer.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnSupprimer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				supprimer();
			}
		});
		btnSupprimer.setBackground(Color.WHITE);
		
		Image img1 = new ImageIcon(this.getClass().getResource("/delete.png")).getImage();
		btnSupprimer.setIcon(new ImageIcon(img1));
		
		lblNewLabel = new JLabel("");
		Image img = new ImageIcon(this.getClass().getResource("/profile.png")).getImage();
		lblNewLabel.setIcon(new ImageIcon(img));
		
		JButton btnRetour = new JButton("Retour");
		btnRetour.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				IntBureauChargInfo bureau = new IntBureauChargInfo();
				bureau.setVisible(true);
				bureau.setLocationRelativeTo(null);
				bureau.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				Profil1.this.dispose();
			}
		});
		btnRetour.setForeground(Color.ORANGE);
		btnRetour.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnRetour.setBackground(Color.WHITE);
		
		jtextField_niveau = new JTextField();
		jtextField_niveau.setColumns(10);
		
		lblNiveau = new JLabel("Niveau");
		lblNiveau.setForeground(Color.ORANGE);
		lblNiveau.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 11));
		
		lblTel = new JLabel("Tel");
		lblTel.setForeground(Color.ORANGE);
		lblTel.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 11));
		
		jtextField_tel = new JTextField();
		jtextField_tel.setColumns(10);
		
		textField_email_1 = new JTextField();
		textField_email_1.setColumns(10);
		
		textField_utilisateur = new JTextField();
		textField_utilisateur.setColumns(10);
		
		lblUtilisateur = new JLabel("utilisateur");
		lblUtilisateur.setForeground(Color.ORANGE);
		lblUtilisateur.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 11));
		
		lblAncienEmail = new JLabel("ancien E-mail");
		lblAncienEmail.setForeground(Color.ORANGE);
		lblAncienEmail.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 11));
		
		textField = new JTextField();
		textField.setColumns(10);
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(18)
					.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 231, GroupLayout.PREFERRED_SIZE)
					.addGap(34)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(lblNom, GroupLayout.PREFERRED_SIZE, 40, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblPrnom, GroupLayout.PREFERRED_SIZE, 62, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblUtilisateur, GroupLayout.PREFERRED_SIZE, 87, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblMotDePasse)
						.addComponent(lblEmail, GroupLayout.PREFERRED_SIZE, 51, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNiveau, GroupLayout.PREFERRED_SIZE, 51, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblTel, GroupLayout.PREFERRED_SIZE, 51, GroupLayout.PREFERRED_SIZE))
					.addGap(5)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(textField_nom, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(textField_prenom, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(textField_utilisateur, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(passwordField, GroupLayout.PREFERRED_SIZE, 116, GroupLayout.PREFERRED_SIZE)
						.addComponent(textField_email_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(jtextField_niveau, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(jtextField_tel, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(151)
					.addComponent(textField_email, GroupLayout.PREFERRED_SIZE, 184, GroupLayout.PREFERRED_SIZE))
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(18)
					.addComponent(lblAncienEmail, GroupLayout.PREFERRED_SIZE, 95, GroupLayout.PREFERRED_SIZE)
					.addGap(37)
					.addComponent(textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(74)
					.addComponent(btnRetour, GroupLayout.PREFERRED_SIZE, 115, GroupLayout.PREFERRED_SIZE)
					.addGap(140)
					.addComponent(btnModifier)
					.addGap(18)
					.addComponent(btnSupprimer))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(lblNewLabel)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(21)
							.addComponent(lblNom)
							.addGap(18)
							.addComponent(lblPrnom)
							.addGap(29)
							.addComponent(lblUtilisateur)
							.addGap(18)
							.addComponent(lblMotDePasse)
							.addGap(18)
							.addComponent(lblEmail)
							.addGap(26)
							.addComponent(lblNiveau)
							.addGap(10)
							.addComponent(lblTel))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(13)
							.addComponent(textField_nom, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addGap(13)
							.addComponent(textField_prenom, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addGap(18)
							.addComponent(textField_utilisateur, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addGap(12)
							.addComponent(passwordField, GroupLayout.PREFERRED_SIZE, 20, GroupLayout.PREFERRED_SIZE)
							.addGap(13)
							.addComponent(textField_email_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addGap(18)
							.addComponent(jtextField_niveau, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addGap(7)
							.addComponent(jtextField_tel, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(174)
							.addComponent(textField_email, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
					.addGap(29)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblAncienEmail)
						.addComponent(textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(20)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(23)
							.addComponent(btnRetour, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE))
						.addComponent(btnModifier, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnSupprimer, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)))
		);
		contentPane.setLayout(gl_contentPane);
	}

	/**r�definition de la methode modifier de l'interface UpdateInDB pourla modification du profil 
	/* (non-Javadoc)
	 * @see connectionDAO.UpdateInDB#modifier()
	 */
	@Override
	public void modifier() {
	
		

		String nom= textField_nom.getText();
		String prenom = textField_prenom.getText();
		String nu = textField_utilisateur.getText(); 
		String mp =String.valueOf(passwordField.getPassword());
		String email = textField_email.getText();
		String niv= jtextField_niveau.getText();
		String tel= jtextField_tel.getText();
		String ancienEmail = textField.getText();
		
		Connect c = new Connect();
		Connection con = c.connect();
		PreparedStatement pst = null;
		
		Register theRegister = new Register (nom,prenom,nu,mp,email,niv,tel);		
		try {
			pst = con.prepareStatement("UPDATE `membre_bureau` SET `Nom` = ?, `Prenom` = ?, `Nom_Utilisateur` = ?, `Mot_de_Passe` = ?, `Email` = ?, `Niveau` = ?, `Tel` = ? WHERE `membre_bureau`.`Email` = ?");
			
			// set params
			pst.setString(1, theRegister.getNom());
			pst.setString(2, theRegister.getPrenom());
			pst.setString(3, theRegister.getNu());
			pst.setString(4, theRegister.getMp());
			pst.setString(5, theRegister.getEmail());
			pst.setString(6, theRegister.getNiv());
			pst.setString(7, theRegister.getTel());
			pst.setString(8, ancienEmail);
			
			// execute SQL
			pst.executeUpdate();
			//to close 
			pst.close();
			
		} catch (SQLException e) {
		
			e.printStackTrace();
		}
	
		
		
	}

	/**r�definition de la methode supprimer de l'interface UpdateInDB pour se 
	 * supprimer � partir de l'amail*/
	@Override
	public void supprimer() {
		
		String email = textField.getText();
		Register register = new Register (email);
		Connect c = new Connect();
		Connection con = c.connect();
		PreparedStatement pst = null;

		try {
			
			pst = con.prepareStatement("DELETE FROM `membre_bureau` WHERE `membre_bureau`.`Email` = ?");
			//set 
			pst.setString(1,register.getEmail());
			//execute
			pst.executeUpdate();
			//close 
			pst.close();
			
		} catch (SQLException e) {e.printStackTrace();} 
		
		
	}

	@Override
	public void afficher() {
		// TODO Auto-generated method stub
		
	}
}
