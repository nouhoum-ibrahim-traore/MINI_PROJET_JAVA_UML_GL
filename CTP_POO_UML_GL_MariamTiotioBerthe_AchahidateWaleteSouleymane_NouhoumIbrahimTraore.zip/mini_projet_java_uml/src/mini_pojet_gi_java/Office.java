package mini_pojet_gi_java;

import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import daodata.MembreBureau;
import net.proteanit.sql.DbUtils;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.table.DefaultTableModel;

import connectionDAO.AddInDB;
import connectionDAO.Connect;
import connectionDAO.UpdateInDB;

import javax.swing.JScrollPane;
import javax.swing.ImageIcon;
import java.awt.Font;
import java.awt.Color;


/**
 * @author Mariam Tiotio Berthe
 * @author Nouhoum Ibrahim Traore
 * @author Achahidat Wallet Souleymane
 * 
 * Class qui herite de jframe et qui implemente les interfaces pour l'ajout,
 * l'affichage la modification et la suppression.
 *Elle permettra � l'admin de modifier,supprimer, ajouter et afficher la liste 
 *d'un membre du bureau 
 */

public class Office extends JFrame implements AddInDB, UpdateInDB {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField jtextField_Nom;
	private JTextField jtextField_Prenom;
	private JTextField jtextField_email;
	private JComboBox<String> comboBox;
	private JButton jBoutton_Ajouter;
	private JButton jBoutton_Modifier;
	private JButton jBoutton_Supprimer;
	private JButton jBoutton_Afficher;
	private JLabel lblId;
	private JTextField jtextField_id;
	private JTable table;
	private JButton btnRetour;
	private JLabel lblNewLabel;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Office frame = new Office();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Office() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 832, 468);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		this.setLocationRelativeTo(null);
		
		JLabel lblNom = new JLabel("Nom");
		lblNom.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNom.setBounds(17, 62, 44, 16);
		
		JLabel lblPrnom = new JLabel("Pr\u00E9nom");
		lblPrnom.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblPrnom.setBounds(17, 109, 75, 16);
		
		JLabel lblEmail = new JLabel("E-mail");
		lblEmail.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblEmail.setBounds(17, 157, 64, 16);
		
		jtextField_Nom = new JTextField();
		jtextField_Nom.setBounds(111, 62, 116, 22);
		jtextField_Nom.setColumns(10);
		
		jtextField_Prenom = new JTextField();
		jtextField_Prenom.setBounds(111, 102, 116, 22);
		jtextField_Prenom.setColumns(10);
		
		jtextField_email = new JTextField();
		jtextField_email.setBounds(111, 154, 116, 22);
		jtextField_email.setColumns(10);
		
		JLabel lblFonction = new JLabel("Fonction");
		lblFonction.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblFonction.setBounds(17, 209, 75, 16);
		
		comboBox = new JComboBox<String>();
		comboBox.setBounds(98, 203, 153, 29);
		comboBox.addItem("Tr�sorier");
		comboBox.addItem("Secretaire");
		
		jBoutton_Ajouter = new JButton("Ajouter");
		jBoutton_Ajouter.setBounds(12, 332, 80, 25);
		jBoutton_Ajouter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ajouter();
			}
		});
		
		jBoutton_Modifier = new JButton("Modifier");
		jBoutton_Modifier.setBounds(104, 332, 99, 25);
		jBoutton_Modifier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				modifier();
			}
		});
		
		jBoutton_Supprimer = new JButton("Supprimer");
		jBoutton_Supprimer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				supprimer();
			}
		});
		jBoutton_Supprimer.setBounds(215, 332, 105, 25);
		
		jBoutton_Afficher = new JButton("Afficher");
		jBoutton_Afficher.setBounds(704, 332, 93, 25);
		jBoutton_Afficher.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				afficher();
			}
		});
		
		lblId = new JLabel("ID");
		lblId.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblId.setBounds(17, 27, 26, 16);
		
		jtextField_id = new JTextField();
		jtextField_id.setBounds(111, 27, 116, 22);
		jtextField_id.setColumns(10);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(269, 18, 508, 267);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"ID", "Nom", "Prenom", "Fonction"
			}
		));
		scrollPane.setViewportView(table);
		contentPane.add(jBoutton_Ajouter);
		contentPane.add(jBoutton_Modifier);
		contentPane.add(jBoutton_Supprimer);
		contentPane.add(jBoutton_Afficher);
		contentPane.add(lblNom);
		contentPane.add(lblPrnom);
		contentPane.add(lblEmail);
		contentPane.add(jtextField_Nom);
		contentPane.add(jtextField_Prenom);
		contentPane.add(jtextField_email);
		contentPane.add(lblFonction);
		contentPane.add(comboBox);
		contentPane.add(lblId);
		contentPane.add(jtextField_id);
		
		btnRetour = new JButton("Retour");
		btnRetour.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Admin admin = new Admin();
				admin.setVisible(true);
				admin.setLocationRelativeTo(null);
				admin.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				Office.this.dispose();
			}
		});

		btnRetour.setBounds(12, 383, 80, 25);
		contentPane.add(btnRetour);
		
		lblNewLabel = new JLabel("");
		lblNewLabel.setBackground(new Color(240, 230, 140));
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\Mariam Tiotio Berthe\\Desktop\\java\\workspace eclipse\\mini_projet_java_uml\\images\\office-mitchell.jpg"));
		lblNewLabel.setBounds(0, 0, 814, 421);
		contentPane.add(lblNewLabel);
	}
	
	/**R�definition de la methode ajouter de l'interface AddInBd pour l'ajout des donn�es 
	 * dans la Table membre_bureau  */
	/* (non-Javadoc)
	 * @see DaoFactory.AddInDB#ajouter()
	 */
	@Override
	public void ajouter() {
		String nom = jtextField_Nom.getText();
		String prenom = jtextField_Prenom.getText();
		String email= jtextField_email.getText();
		String fonction = comboBox.getSelectedItem().toString();
		MembreBureau membreBureau = new MembreBureau (nom,prenom,email,fonction);
		
		Connect c = new Connect();
		Connection con = c.connect();
		PreparedStatement pst = null;
		
		
				
		try {
			pst = con.prepareStatement("INSERT INTO Membre_Bureau (Nom,Prenom,Email,Fonction) VALUES (?,?,?,?)");
			
			// set params
			pst.setString(1, membreBureau.getNom());
			pst.setString(2, membreBureau.getPrenom());
			pst.setString(3, membreBureau.getEmail());
			pst.setString(4,membreBureau.getFonction());
			pst.executeUpdate();
			
			pst.close();
		} catch (SQLException e) {

			e.printStackTrace();
		}
		
		JOptionPane.showMessageDialog(null,"Ajout r�ussi !!!");
	
		
	}

	/**r�definition de la methode modifier de l'interface UpdateInDB pour la modification de la fonction
	 * d'un membre de bureau  
	 */
	/* (non-Javadoc)
	 * @see DaoFactory.UpdateInDB#modifier()
	 */
	@Override
	public void modifier() {
		int id= Integer.parseInt(jtextField_id.getText());
		String fonction= comboBox.getSelectedItem().toString();
		MembreBureau membreBureau = new MembreBureau (fonction,id);
		Connect c = new Connect();
		Connection con = c.connect();
		PreparedStatement pst = null;

		try {
			
			pst = con.prepareStatement("UPDATE Membre_Bureau SET Fonction = ? WHERE Membre_Bureau.ID = ?");
			//set 
			pst.setString(1, membreBureau.getFonction());
			pst.setInt(2, membreBureau.getId());
			//execute
			pst.executeUpdate();
			//close 
			pst.close();
			
		} catch (SQLException e) {e.printStackTrace();} 

	}

	/**r�definition de la methode supprimer de l'interface UpdateInDB pour supprimer un membre  
	 */
	/* (non-Javadoc)
	 * @see DaoFactory.UpdateInDB#supprimer()
	 */
	@Override
	public void supprimer() {
		int id= Integer.parseInt(jtextField_id.getText());
		MembreBureau membreBureau = new MembreBureau (id);
		Connect c = new Connect();
		Connection con = c.connect();
		PreparedStatement pst = null;

		try {
			
			pst = con.prepareStatement("DELETE FROM `Membre_Bureau` WHERE `Membre_Bureau`.`ID` = ?");
			//set 
			pst.setInt(1, membreBureau.getId());
			//execute
			pst.executeUpdate();
			//close 
			pst.close();
			
		} catch (SQLException e) {e.printStackTrace();} 
	}

	/**r�definition de la methode afficher de l'interface UpdateInDB pour voir la liste des membre 
	 * du bureau dans un jtable  
	 */
	/* (non-Javadoc)
	 * @see DaoFactory.UpdateInDB#afficher()
	 */
	@Override
	public void afficher() {
		Connect c = new Connect();
		Connection con = c.connect();
		PreparedStatement pst = null;
		ResultSet rs = null;
		try {
			pst = con.prepareStatement("SELECT ID,Nom,Prenom,Fonction FROM Membre_Bureau ");
			rs = pst.executeQuery();
			table.setModel(DbUtils.resultSetToTableModel(rs));
			
			//close
			pst.close();
			rs.close();
		} catch (SQLException e) {e.printStackTrace();}
				
	}
}
