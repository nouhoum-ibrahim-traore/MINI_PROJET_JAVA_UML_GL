package mini_pojet_gi_java;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.ImageIcon;

/**
 * @author Mariam Tiotio Berthe
 * @author Nouhoum Ibrahim Traore
 * @author Achahidat Wallet Souleymane
 * 
 * classe qui h�rute de jFrame 
 * interface admin
 */
 
public class Admin extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Admin frame = new Admin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Admin() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 730, 531);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		this.setLocationRelativeTo(null);
		
		JButton btnBureau = new JButton("Membre du bureau");
		btnBureau.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnBureau.setBounds(12, 391, 222, 25);
		btnBureau.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Office office = new Office();
				office.setVisible(true);
				office.setLocationRelativeTo(null);
				office.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				Admin.this.dispose();
			}
		});
		
		JButton btnHorsBureau = new JButton("Non membres du bureau");
		btnHorsBureau.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnHorsBureau.setBounds(446, 391, 254, 25);
		btnHorsBureau.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				OutOffice outOffice = new OutOffice();
				outOffice.setVisible(true);
				outOffice.setLocationRelativeTo(null);
				outOffice.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				Admin.this.dispose();
				
			}
		});
		contentPane.setLayout(null);
		contentPane.add(btnBureau);
		contentPane.add(btnHorsBureau);
		
		JButton btnDeconexion = new JButton("Deconexion");
		btnDeconexion.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Login log = new Login();
				log.setVisible(true);
				log.setLocationRelativeTo(null);
				log.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				Admin.this.dispose();
			}
		});
		btnDeconexion.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnDeconexion.setBounds(12, 446, 222, 25);
		contentPane.add(btnDeconexion);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\Mariam Tiotio Berthe\\Desktop\\java\\workspace eclipse\\mini_projet_java_uml\\images\\admin-mitchell.jpg"));
		lblNewLabel.setBounds(0, 0, 712, 484);
		contentPane.add(lblNewLabel);
	}

}
