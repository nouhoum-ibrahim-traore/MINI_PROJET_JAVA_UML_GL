/**
 * 
 */
package connectionDAO;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * @author Mariam Tiotio Berthe
 *
 */
public class Connect {
	
	private Connection con = null;
	
	public Connection connect() {
		// get db properties
				Properties props = new Properties();
				try {
					props.load(new FileInputStream("demo.properties"));
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				String user = props.getProperty("user");
				String password = props.getProperty("password");
				String dburl = props.getProperty("dburl");
				
				// connect to database
				try {
					con = (Connection) DriverManager.getConnection(dburl, user, password);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				System.out.println("DB connection successful to: " + dburl);
				return con;
			}
			
			
	}
	


