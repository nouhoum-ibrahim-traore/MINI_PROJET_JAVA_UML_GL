/**
 * 
 */
package connectionDAO;

/**
 * @author Mariam Tiotio Berthe
 *
 */
public interface UpdateInDB {
	
	void modifier ();
	
	void supprimer();
	
	void afficher();

}
