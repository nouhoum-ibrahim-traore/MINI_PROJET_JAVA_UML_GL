/**
 * 
 */
package connectionDAO;

/**
 * @author Mariam Tiotio Berthe
 *
 */
public interface AddInDB {
	void ajouter();

}
